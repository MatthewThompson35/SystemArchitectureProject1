package edu.westga.cs3110.unicoder.model;

public class Codepoint {

}
