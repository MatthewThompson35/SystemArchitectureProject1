package edu.westga.cs3110.unicoder.tests.model.codepoint;

public class TestConstructor {

}
